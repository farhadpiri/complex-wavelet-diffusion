function [abs, phase, Io]= imReal(re,im)
abs=sqrt(re.^2+im.^2);
phase=atan2(im,re);
Io=abs.*exp(1i.*phase);
