clc;clear all;close all;
I=imread('den2.jpg');
% % make image a double and normalize
I=I(:,:,1);
I = double(I);
mx = max(I(:));
mn = min(I(:));
I = (I-mn)/(mx-mn);
nither=3;

% get area of uniform speckle

    figure, imshow(I,[],'InitialMagnification','fit');
    rect = getrect;
    close;
Iuniform = imcrop(I,rect);
lambda1=0;
lambda=0.02;
S3=0;
alpha=1;
% q0_squared = (std(Iuniform(:))/mean(Iuniform(:)))^2;
% lambda =16* std(Iuniform(:))/mean(Iuniform(:));
pause(10);
for ither=1:nither
  J = 1;
  [Faf, Fsf] = FSfarras;
  [af, sf] = dualfilt1;
  w = cplxdual2D(I, J, Faf, af);
 adw=w;
 blk=7;
 bls=(blk-1)/2;

%  for k=1:J
%      for rim=1:2
%          for np=1:2
%             for o=1:3
%            S= w{k}{rim}{np}{o};     
%            S2=imcrop(S,rect/(2^J));
%            S3=S3+numel(S2);
%            lambda1=lambda1+sum(S2(:));
%             end
%          end
%      end
%  end
% lambda=alpha*lambda1/S3;
%   err = x - y;
%   max(max(abs(err)))
for k=1:J
           for np=1:2
            for o=1:3
                re=w{k}{1}{np}{o}; 
                im=w{k}{2}{np}{o}; 
                
            adw{k}{1}{np}{o}=  w{k}{1}{np}{o};   
            adw{k}{2}{np}{o}=  w{k}{2}{np}{o};  
            [abs,phase,Io]=imReal(re,im);
            
            D = abs;
%             S2=imcrop(D,rect/(2^J));
%             S3=numel(S2);
%             lambda1=sum(S2(:));
%             lambda=alpha*lambda1/S3;
            u=size(D,1);
            v=size(D,2);
            X=zeros((u+blk-1),(v+blk-1));
            X(bls+1:u+bls,bls+1:(u+bls))=D;
            z=zeros(u,v);
            for i=1:u
               for j=1:v
               window=X(i:i+bls*2,j:j+bls*2);
               z(i,j)=mean(window(:));
               end
            end
            N=D./z;
            N(isnan(N))=0;
            if (J>=2)
              lambda=lambda/sqrt(2);
            end
            P11=(N<=lambda);
            P12=(N>0);
            P13=P12.*P11;
            P1=P13.*(1.5*exp(-(N.^2-(lambda)^2)./((lambda^2)*(1+lambda^2))));
            P22=(N>lambda);
            P2=P22.*(1.8*exp(-3.315./((N./lambda).^4)));  
            P3=-1*((N<0)-1);
            P=(P1+P2).*P3;
            adw{k}{1}{np}{o}=real(Io).*P;
            adw{k}{2}{np}{o}=imag(Io).*P;
            end
           end 
  

end
 I = icplxdual2D(adw, J, Fsf, sf);
 A = double(I);
                 mx = max(A(:));
                 mn = min(A(:));
                 I = (A-mn)/(mx-mn);
end
 figure,

 y=I;
  
 miny=min(y(:));
 maxy=max(y(:));
 y=(y-miny)/(maxy-miny);
y = round(y.*255);
imshow(I);
% grayImage=I;
% lowPass =Io;
% size(Io)
% size(I)
% noiseOnlyImage = im2double(grayImage(:,:,1)) - im2double(lowPass(:,:,1));
% noiseVar = var(noiseOnlyImage);
% size(noiseVar)
% min(noiseVar)
% max(noiseVar)
