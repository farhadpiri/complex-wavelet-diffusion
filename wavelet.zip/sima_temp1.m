clear all
clc
close all

addpath('E:\dar30\curvelet diffusion\wavelet diffusion\Complex Wavelet\allcode')
Noisy_im=imread('SRAD_im.bmp');
Noisy_im=im2double(rgb2gray(Noisy_im));
J = 5;
[Faf, Fsf] = FSfarras;
[af, sf] = dualfilt1;
w = cplxdual2D(Noisy_im, J, Faf, af);